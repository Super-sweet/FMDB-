//
//  AppDelegate.h
//  Scanner
//
//  Created by xuchao on 16/8/3.
//  Copyright © 2016年 none. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString * _name;
    BOOL * _callEdit;
}
@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,assign) BOOL callEdit;

@property (nonatomic,copy) NSString *name;
@end

