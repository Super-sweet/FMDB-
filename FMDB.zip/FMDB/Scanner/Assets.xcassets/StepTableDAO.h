//
//  StepTableDAO.h
//  Scanner
//
//  Created by xuchao on 16/8/5.
//  Copyright © 2016年 none. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StepTableDAO : NSObject

+ (void)creatStepTable;


+ (void)insertStepCount:(NSString *)str;

+ (void)deleteStepCount:(NSString *)str;

+ (void)queryAll:(NSString *)str;
+ (void)updateStepCount:(NSString *)str;
@end
