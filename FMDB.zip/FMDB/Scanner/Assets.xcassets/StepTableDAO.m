//
//  StepTableDAO.m
//  Scanner
//
//  Created by xuchao on 16/8/5.
//  Copyright © 2016年 none. All rights reserved.
//

#import "StepTableDAO.h"
#import "HYSqliteManager.h"

@implementation StepTableDAO

+ (void)creatStepTable {

    FMDatabase * dataBase = [HYSqliteManager shareDatabase];
    if (![dataBase open]) {
        [dataBase open];
    }
    
    if ([dataBase tableExists:@"PersonList"]== NO) {
        [dataBase executeUpdate:@"CREATE TABLE PersonList (NameID  INTEGER PRIMARY KEY AUTOINCREMENT , Name text)"];

    }
    [dataBase close];
}

+ (void)insertStepCount:(NSString *)str {
    FMDatabase * db = [HYSqliteManager shareDatabase];
    [db open];
    [db executeUpdate:@"INSERT INTO PersonList (Name) values (?)",str];
    [db close];
    

}
+ (void)updateStepCount:(NSString *)str {
    FMDatabase * db = [HYSqliteManager shareDatabase];
    [db open];
    [db executeUpdate:@"UPDATE PersonList SET Name = ? WHERE NameID = 2",str];
    [db close];
    

}
+ (void)deleteStepCount:(NSString *)str {

    FMDatabase * db = [HYSqliteManager shareDatabase];
    [db open];
    [db executeUpdate:@"DELETE FROM PersonList WHERE Name = '小明'"];
    [db close];
    
    
   }

+ (void)queryAll:(NSString *)str {

    FMDatabase * db = [HYSqliteManager shareDatabase];
    [db open];
    NSString * sql = @"SELECT * FROM PersonList";
    NSMutableArray * arr= [NSMutableArray array];
    FMResultSet * set =  [db executeQuery:sql];
    while ([set next]) {
        NSString * str = [set stringForColumn:@"Name"];
        [arr addObject:str];
    }
    [set close];
    [db close];
    NSLog(@"%@",arr);


}

@end
