//
//  HYSqliteManager.h
//  Scanner
//
//  Created by xuchao on 16/8/4.
//  Copyright © 2016年 none. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDB.h>
@interface HYSqliteManager : NSObject

+ (FMDatabase *)shareDatabase;
@end
