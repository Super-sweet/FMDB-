//
//  HYSqliteManager.m
//  Scanner
//
//  Created by xuchao on 16/8/4.
//  Copyright © 2016年 none. All rights reserved.
//

#import "HYSqliteManager.h"

static FMDatabase *__db;
@implementation HYSqliteManager

+ (FMDatabase *)shareDatabase {

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __db = [[FMDatabase alloc]initWithPath:[self path]];
        
    });
    return __db;
}

+ (NSString *)path {
    NSString * path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/steps.sqlite"];
    NSLog(@"%@",path);
    return path;

}
@end
