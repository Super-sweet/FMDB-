//
//  ViewController.m
//  Scanner
//
//  Created by xuchao on 16/8/3.
//  Copyright © 2016年 none. All rights reserved.
//

#import "ViewController.h"
#import <ReactiveCocoa/ReactiveCocoa.h>
#import "StepTableDAO.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   // [StepTableDAO creatStepTable];
    
    
   
//    [[self.button rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x){
//        UIButton * btn = x;
//        
//        NSLog(@"%@",btn.titleLabel.text);
//    }];
//   
//    [[self.button rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
//        UIButton * btn = x;
//        
//        NSLog(@"%@",btn.titleLabel.text);
//
//    } error:^(NSError *error) {
//        NSLog(@"%@",error);
//    }];
//    
//    
//RAC(self.view,backgroundColor) = [self.textfiled.rac_textSignal map:^id(id value) {
//    return [value boolValue] ? [UIColor redColor] : [UIColor yellowColor];
//}];
    
    
   
    [[self.creatButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        [StepTableDAO creatStepTable];
    }];
    
    
    [[self.insertButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        [StepTableDAO insertStepCount:@"55"];
    }];
    
    [[self.updateButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        [StepTableDAO updateStepCount:@"小明"];
    }];
    [[self.searchButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        [StepTableDAO queryAll:nil];
    }];
    [[self.deleteButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        [StepTableDAO deleteStepCount:nil];
    }];
   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
